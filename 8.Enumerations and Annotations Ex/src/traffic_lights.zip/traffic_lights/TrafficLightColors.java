package traffic_lights;

/**
 * Created by Sim0o on 3/27/2017.
 */
public enum  TrafficLightColors
{
    RED,GREEN,YELLOW
}
