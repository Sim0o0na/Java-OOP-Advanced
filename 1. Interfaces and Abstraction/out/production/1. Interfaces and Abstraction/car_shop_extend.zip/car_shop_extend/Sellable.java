package car_shop_extend;


/**
 * Created by Sim0o0na on 3/14/2017.
 */
public interface Sellable extends Car {
    Double gerPrice();
}
