package car_shop;

import java.util.Set;

/**
 * Created by Sim0o on 3/14/2017.
 */
public interface Serializable {

}
