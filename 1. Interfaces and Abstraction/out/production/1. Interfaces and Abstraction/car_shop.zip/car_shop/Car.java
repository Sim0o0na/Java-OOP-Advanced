package car_shop;

/**
 * Created by Sim0o on 3/14/2017.
 */
public interface Car {
    Integer TIRES = 4;
    String getModel();
    String getColor();
    Integer getHorsePower();
    String toString();
}
