package weekdays;

/**
 * Created by Sim0o on 3/23/2017.
 */
public class Main {
    public static void main(String[] args) {
//        WeeklyCalendar calendar = new WeeklyCalendar();
//        calendar.addEntry("Monday", "sport");
//        calendar.addEntry("Friday", "sleeping");
//        calendar.addEntry("Wednesday", "sleeping");
//        for(WeeklyEntry we:calendar.getWeeklySchedule()){
//            System.out.println(we.toString());
//        }
    }
}
