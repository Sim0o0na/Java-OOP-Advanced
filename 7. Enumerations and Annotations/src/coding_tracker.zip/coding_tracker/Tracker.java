package coding_tracker;

/**
 * Created by Sim0o on 3/27/2017.
 */
public class Tracker {
    @Author(name = "Pesho")
    static void printMethodsByAuthor(Class<?> cl){}
}
