package coffee_machine;

/**
 * Created by Sim0o on 3/23/2017.
 */
public enum CoffeeType {
    ESPRESSO, LATTE, IRISH


}
