package warning_levels;

/**
 * Created by Sim0o on 3/23/2017.
 */
public enum Importance {
    LOW, NORMAL, MEDIUM, HIGH
}
