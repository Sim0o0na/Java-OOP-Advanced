package create_annotation;

/**
 * Created by Sim0o on 3/23/2017.
 */
@Subject(categories = {"Test", "Annotations"})
public class Test {
}
