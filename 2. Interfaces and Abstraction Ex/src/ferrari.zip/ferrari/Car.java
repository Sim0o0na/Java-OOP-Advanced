package ferrari;

/**
 * Created by Sim0o on 3/14/2017.
 */
public interface Car {
    String brake();
    String gas();
}
