package birthday_celebrations;

/**
 * Created by Sim0o on 3/14/2017.
 */
public class Pet
{
    private String name;
    private String birthday;

    public Pet(String name, String birthday){
        this.name = name;
        this.birthday = birthday;
    }
}
