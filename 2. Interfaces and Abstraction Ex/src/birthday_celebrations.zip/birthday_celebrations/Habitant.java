package birthday_celebrations;

/**
 * Created by Sim0o on 3/14/2017.
 */
public interface Habitant {
    String getId();
}
