package multiple_implementation;

/**
 * Created by Sim0o on 3/14/2017.
 */
public interface Identifiable {
    String getId();
}
