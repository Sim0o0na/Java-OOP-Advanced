package inteface_person;

/**
 * Created by Sim0o on 3/14/2017.
 */
public interface Person {
    String getName();
    int getAge();
}
