package telephony;

/**
 * Created by Sim0o on 3/14/2017.
 */
public interface Phone extends Software {
    String callNumber(String phone);
    String browsePage(String page);
}
