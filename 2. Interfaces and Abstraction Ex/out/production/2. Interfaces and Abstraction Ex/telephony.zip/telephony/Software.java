package telephony;

/**
 * Created by Sim0o on 3/14/2017.
 */
public interface Software {
    String call(String phone);
    String browse(String url);
}
