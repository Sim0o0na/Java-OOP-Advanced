package military_elite;

import java.util.HashSet;
import java.util.List;

/**
 * Created by Sim0o on 3/15/2017.
 */
public interface ILeutenantGeneral extends IPrivate {
    List<String> getPrivates();
}
