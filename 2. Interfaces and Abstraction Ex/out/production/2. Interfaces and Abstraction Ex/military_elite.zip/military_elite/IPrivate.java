package military_elite;

import java.time.chrono.IsoChronology;

/**
 * Created by Sim0o on 3/15/2017.
 */
public interface IPrivate extends ISoldier {
    double getSalary();
}
