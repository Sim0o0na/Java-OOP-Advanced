package tuple;

/**
 * Created by Sim0o on 3/17/2017.
 */
import java.util.List;
import java.util.Map;

public class Tuple<TKey, TValue> implements Map.Entry<TKey, TValue>
{
    private TKey item1;
    private TValue item2;

    public Tuple(TKey key, TValue value)
    {
        this.item1 = key;
        this.item2 = value;
    }

    public TKey getKey()
    {
        return this.item1;
    }

    public TValue getValue()
    {
        return this.item2;
    }

    public TKey setKey(TKey key)
    {
        return this.item1 = key;
    }

    public TValue setValue(TValue value)
    {
        return this.item2 = value;
    }

    @Override
    public String toString(){
        return String.format("%s -> %s", this.getKey(), this.getValue());
    }
}