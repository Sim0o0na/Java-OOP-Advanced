package pr0304Barracks.core.commands;

import pr0304Barracks.contracts.Repository;
import pr0304Barracks.contracts.UnitFactory;

import java.lang.reflect.InvocationTargetException;

/**
 * Created by Sim0o on 3/31/2017.
 */
public class Report extends Command {
    public Report(String[] data, Repository repo, UnitFactory factory) {
        super(data, repo, factory);
    }

    @Override
    public String execute() throws ClassNotFoundException, NoSuchMethodException, InvocationTargetException, InstantiationException, IllegalAccessException {
        return this.getRepo().getStatistics();
    }
}
