package pr0304Barracks.core.commands;


import pr0304Barracks.contracts.Executable;
import pr0304Barracks.contracts.Repository;
import pr0304Barracks.contracts.UnitFactory;

/**
 * Created by Sim0o on 3/31/2017.
 */
public abstract class Command implements Executable{
    private String[] data;
    private Repository repo;
    private UnitFactory factory;

    public Command(String[] data, Repository repo, UnitFactory factory){
        this.data = data;
        this.repo = repo;
        this.factory = factory;
    }

    public String[] getData(){
        return this.data;
    }

    public Repository getRepo(){
        return this.repo;
    }

    public UnitFactory getFactory(){
        return this.factory;
    }
}
