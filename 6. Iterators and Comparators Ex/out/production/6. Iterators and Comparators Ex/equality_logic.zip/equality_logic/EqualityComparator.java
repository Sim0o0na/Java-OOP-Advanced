package equality_logic;

import java.util.Collections;
import java.util.Comparator;

/**
 * Created by Sim0o on 3/22/2017.
 */
public class EqualityComparator implements Comparator<Person> {
    @Override
    public int compare(Person o1, Person o2) {
        if(o1.getName().equals(o2.getName()) && o1.getAge()==o2.getAge()){
            return 0;
        }
        else{
            return -1;
        }
    }
}
