package generic_flat_method;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.NavigableMap;

/**
 * Created by Sim0o on 3/16/2017.
 */
public class Main {
    public static void main(String[] args) {
//        List<Integer> integers = new ArrayList<>();
//        Collections.addAll(integers, 1,2,3);
//
//        List<Double> doubles = new ArrayList<>();
//        Collections.addAll(doubles, 1.2,2.5,3.4);
//
//        List<List<? extends Number>> listche = new ArrayList<>();
//        Collections.addAll(listche, integers, doubles);
//
//        List<Number> destination = new ArrayList<>();
//        ListUtils.flatten(destination, listche);
//        System.out.println(destination);
    }
}

