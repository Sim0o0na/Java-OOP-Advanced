package null_finder;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * Created by Sim0o on 3/16/2017.
 */
public class Main {
    public static void main(String[] args) {
//        List<String> listche = new ArrayList<>();
//        Collections.addAll(listche, null, null, "simona1");
//        System.out.println(ListUtils.getNullIndices(listche));
    }
}
