package list_utilities;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * Created by Sim0o on 3/16/2017.
 */
public class Main {
    public static void main(String[] args) {
//        List<Integer> listche = new ArrayList<>();
//        Collections.addAll(listche, 1, 2 ,3,6,5,9);
//        System.out.println(ListUtils.getMax(listche));
//        System.out.println(ListUtils.getMin(listche));
    }
}
